import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Splash = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.splashPressable}
      onPress={() => navigation.navigate("Location")}
    >
      <View style={styles.groupView1}>
        <View style={styles.groupView}>
          <View style={styles.rectangleView} />
          <View style={styles.rectangleView1} />
          <View style={styles.rectangleView2} />
        </View>
        <Text style={styles.fastNewsText}>FastNews</Text>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  rectangleView: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#4236d1",
    width: 50,
    height: 5,
  },
  rectangleView1: {
    position: "absolute",
    top: 8,
    left: 14,
    backgroundColor: "#4236d1",
    width: 36,
    height: 5,
  },
  rectangleView2: {
    position: "absolute",
    top: 16,
    left: 30,
    backgroundColor: "#4236d1",
    width: 20,
    height: 5,
  },
  groupView: {
    position: "absolute",
    top: 8,
    left: 0,
    width: 50,
    height: 21,
  },
  fastNewsText: {
    position: "absolute",
    top: 0,
    left: 58,
    fontSize: 30,
    fontWeight: "800",
    fontFamily: "Mulish",
    color: "#4236d1",
    textAlign: "center",
  },
  groupView1: {
    position: "absolute",
    top: 372,
    left: 86,
    width: 202,
    height: 38,
  },
  splashPressable: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Splash;
