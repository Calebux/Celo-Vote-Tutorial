import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const ReadMode = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.readModeView}>
      <Image
        style={styles.download2Icon}
        resizeMode="cover"
        source={require("../assets/download-2.png")}
      />
      <View style={styles.systemStatusBarLight}>
        <View style={styles.rectangleView} />
        <Image
          style={styles.cover1Icon}
          resizeMode="cover"
          source={require("../assets/cover-14.png")}
        />
        <View style={styles.rectangleView1} />
        <View style={styles.containerView} />
        <View style={styles.rectangleView2} />
        <Image
          style={styles.statusBarBattery}
          resizeMode="cover"
          source={require("../assets/status-bar--battery.png")}
        />
        <Image
          style={styles.statusBarWiFi}
          resizeMode="cover"
          source={require("../assets/status-bar--wifi4.png")}
        />
        <View style={styles.statusBarService}>
          <View style={styles.signalView}>
            <View style={styles.barView} />
            <View style={styles.barView1} />
            <View style={styles.barView2} />
            <View style={styles.barView3} />
          </View>
        </View>
        <View style={styles.timeView}>
          <View style={styles.statusBarLocation}>
            <View style={styles.boundsView} />
            <Image
              style={styles.locationIcon}
              resizeMode="cover"
              source={require("../assets/location.png")}
            />
          </View>
          <Text style={styles.text}>12:22</Text>
        </View>
      </View>
      <Text style={styles.appleLaunchesIOS16}>Apple Launches IOS 16</Text>
      <View style={styles.groupView}>
        <View style={styles.rectangleView3} />
        <View style={styles.rectangleView4} />
        <View style={styles.rectangleView5} />
      </View>
      <View style={styles.groupView2}>
        <View style={styles.groupView1}>
          <View style={styles.rectangleView6} />
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/521-1.png")}
          />
        </View>
        <Image
          style={styles.rectangleIcon}
          resizeMode="cover"
          source={require("../assets/rectangle-7.png")}
        />
        <Text style={styles.vanguardText}>Vanguard</Text>
      </View>
      <Image
        style={styles.vuesaxtwotonearchiveTickIcon}
        resizeMode="cover"
        source={require("../assets/vuesaxtwotonearchivetick4.png")}
      />
      <View style={styles.frameView1}>
        <View style={styles.groupView15}>
          <Text style={styles.relatedNewsText}>Related news</Text>
          <View style={styles.groupView5}>
            <View style={styles.groupView3}>
              <Text style={styles.appleLaunchesIOS161}>
                Apple Launches IOS 16
              </Text>
              <Text style={styles.iPadOS16IsTheFourthAndUp}>
                <Text
                  style={styles.iPadOS16Is}
                >{`iPadOS 16 is the fourth and `}</Text>
                <Text style={styles.upcomingMajorRelease}>
                  upcoming major release of
                </Text>
                <Text style={styles.theIPadOSOperate}>the iPadOS operate</Text>
              </Text>
            </View>
            <View style={styles.groupView4}>
              <View style={styles.rectangleView7} />
              <Image
                style={styles.download1Icon}
                resizeMode="cover"
                source={require("../assets/download-16.png")}
              />
            </View>
          </View>
          <View style={styles.groupView8}>
            <View style={styles.groupView6}>
              <Text style={styles.appleLaunchesIOS162}>
                Apple Launches IOS 16
              </Text>
              <Text style={styles.iPadOS16IsTheFourthAndUp1}>
                <Text
                  style={styles.iPadOS16Is1}
                >{`iPadOS 16 is the fourth and `}</Text>
                <Text style={styles.upcomingMajorRelease1}>
                  upcoming major release of
                </Text>
                <Text style={styles.theIPadOSOperate1}>the iPadOS operate</Text>
              </Text>
            </View>
            <View style={styles.groupView7}>
              <View style={styles.rectangleView8} />
              <Image
                style={styles.download1Icon1}
                resizeMode="cover"
                source={require("../assets/download-16.png")}
              />
            </View>
          </View>
          <View style={styles.groupView11}>
            <View style={styles.groupView9}>
              <Text style={styles.appleLaunchesIOS163}>
                Apple Launches IOS 16
              </Text>
              <Text style={styles.iPadOS16IsTheFourthAndUp2}>
                <Text
                  style={styles.iPadOS16Is2}
                >{`iPadOS 16 is the fourth and `}</Text>
                <Text style={styles.upcomingMajorRelease2}>
                  upcoming major release of
                </Text>
                <Text style={styles.theIPadOSOperate2}>the iPadOS operate</Text>
              </Text>
            </View>
            <View style={styles.groupView10}>
              <View style={styles.rectangleView9} />
              <Image
                style={styles.download1Icon2}
                resizeMode="cover"
                source={require("../assets/download-16.png")}
              />
            </View>
          </View>
          <View style={styles.groupView14}>
            <View style={styles.groupView12}>
              <Text style={styles.appleLaunchesIOS164}>
                Apple Launches IOS 16
              </Text>
              <Text style={styles.iPadOS16IsTheFourthAndUp3}>
                <Text
                  style={styles.iPadOS16Is3}
                >{`iPadOS 16 is the fourth and `}</Text>
                <Text style={styles.upcomingMajorRelease3}>
                  upcoming major release of
                </Text>
                <Text style={styles.theIPadOSOperate3}>the iPadOS operate</Text>
              </Text>
            </View>
            <View style={styles.groupView13}>
              <View style={styles.rectangleView10} />
              <Image
                style={styles.download1Icon3}
                resizeMode="cover"
                source={require("../assets/download-16.png")}
              />
            </View>
          </View>
        </View>
        <Text style={styles.applesLatestAnnouncementHa}>
          <Text style={styles.applesLatestAnnouncement}>
            Apple's latest announcement has
          </Text>
          <Text style={styles.manyPeopleExcited}>
            many people excited for the
          </Text>
          <Text style={styles.launchOfThe}>
            launch of the new iPhone 14 range of smartphone devices,
          </Text>
          <Text style={styles.butIfOwning}>
            {" "}
            but if owning the latest tech has never
          </Text>
          <Text style={styles.reallyBeenYour}>
            {" "}
            really been your top priority, then we have
          </Text>
          <Text style={styles.someGoodNews}> some good news for you.</Text>
          <Text style={styles.wheneverTheLatest}>
            Whenever the latest iPhone is released,
          </Text>
          <Text style={styles.theOlderModels}>
            {" "}
            the older models tend to drop in price –
          </Text>
          <Text
            style={styles.kindaTheSame}
          >{` kinda the same as how FIFA games are `}</Text>
          <Text style={styles.worthOnlyPennies}>
            worth only pennies as soon as the latest
          </Text>
          <Text style={styles.oneLaunchesThe}>
            {" "}
            one launches. The iPhone 14 Pro will launch
          </Text>
          <Text style={styles.onSeptember16}>
            {" "}
            on September 16, 2022, but will the model be the best iPhone for
            photography
          </Text>
          <Text style={styles.opensInNew}>
            (opens in new tab)? And will it cause last
          </Text>
          <Text style={styles.yearsIPhone13}>
            {" "}
            year's iPhone 13 Pro to drop in price?
          </Text>
          <Text style={styles.text1}></Text>
          <Text style={styles.ifYouDidnt}>
            If you didn't see Apple's launch event,
          </Text>
          <Text
            style={styles.heresHowThe}
          >{` here's how the new iPhone 14 lineup `}</Text>
          <Text style={styles.comparesopensInNew}>
            compares(opens in new tab).
          </Text>
          <Text style={styles.theLatestIPhone}>
            {" "}
            The latest iPhone 14 announcement
          </Text>
          <Text style={styles.opensInNew1}>
            (opens in new tab) from Apple was a
          </Text>
          <Text style={styles.bigOneAnnouncing}>
            {" "}
            big one, announcing four new models,
          </Text>
          <Text style={styles.asWellAs}>
            {" "}
            as well as mega main camera upgrades
          </Text>
          <Text style={styles.forTheIPhone}>
            {" "}
            for the iPhone 14 Pro and Pro Max, with
          </Text>
          <Text style={styles.a48MPCameraopens}>
            {" "}
            a 48MP camera(opens in new tab)
          </Text>
          <Text style={styles.a65Larger}>
            {" "}
            (a 65% larger sensor than on the previous
          </Text>
          <Text style={styles.iPhone13Pro}>
            {" "}
            iPhone 13 Pro and Max models) as well
          </Text>
          <Text style={styles.asAnAdvanced}>
            {" "}
            as an advanced quad-pixel sensor with
          </Text>
          <Text style={styles.anAdditional2x}>
            {" "}
            an additional 2x Telephoto lenses.
          </Text>
          <Text style={styles.text2}></Text>
        </Text>
        <Text style={styles.minAgoText}>2 Min ago</Text>
        <Text style={styles.minAgoText1}>2 Min ago</Text>
        <Text style={styles.minAgoText2}>2 Min ago</Text>
        <Text style={styles.minAgoText3}>2 Min ago</Text>
        <View style={styles.groupView17}>
          <View style={styles.rectangleView11} />
          <View style={styles.frameView}>
            <Image
              style={styles.fluentnext28FilledIcon}
              resizeMode="cover"
              source={require("../assets/fluentnext28filled.png")}
            />
            <View style={[styles.antDesignpauseCircleFilledView, styles.ml25]}>
              <Image
                style={styles.vectorIcon}
                resizeMode="cover"
                source={require("../assets/vector.png")}
              />
              <View style={styles.rectangleView12} />
            </View>
            <Image
              style={[styles.fluentnext28FilledIcon1, styles.ml25]}
              resizeMode="cover"
              source={require("../assets/fluentnext28filled1.png")}
            />
          </View>
          <View style={styles.groupView16}>
            <View style={styles.rectangleView13} />
            <View style={styles.rectangleView14} />
            <Text style={styles.text3}>1:20</Text>
            <Text style={styles.text4}>4.70</Text>
          </View>
          <Image
            style={styles.ellipseIcon}
            resizeMode="cover"
            source={require("../assets/ellipse-10.png")}
          />
          <Pressable
            style={styles.tablerarrowsDiagonalMinimizPressable}
            onPress={() => navigation.navigate("ReadMode3")}
          >
            <Image
              style={styles.icon1}
              resizeMode="cover"
              source={require("../assets/tablerarrowsdiagonalminimize2.png")}
            />
          </Pressable>
        </View>
      </View>
      <Pressable
        style={styles.groupPressable}
        onPress={() => navigation.navigate("ReadMode2")}
      >
        <Image
          style={styles.antDesignplayCircleTwotoneIcon}
          resizeMode="cover"
          source={require("../assets/antdesignplaycircletwotone.png")}
        />
        <Text style={styles.readText}>Read</Text>
      </Pressable>
      <Pressable
        style={styles.biarrowLeftCirclePressable}
        onPress={() => navigation.navigate("Home3")}
      >
        <Image
          style={styles.icon2}
          resizeMode="cover"
          source={require("../assets/biarrowleftcircle.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  ml25: {
    marginLeft: 25,
  },
  download2Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 268,
  },
  rectangleView: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "#1c1a29",
    display: "none",
  },
  cover1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 812,
    display: "none",
  },
  rectangleView1: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "rgba(23, 20, 36, 0.85)",
    display: "none",
  },
  containerView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#040404",
    display: "none",
    opacity: 0,
  },
  rectangleView2: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  statusBarBattery: {
    position: "absolute",
    height: "45.45%",
    width: "7.2%",
    top: "27.27%",
    right: "4%",
    bottom: "27.27%",
    left: "88.8%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarWiFi: {
    position: "absolute",
    height: "45.45%",
    width: "5.33%",
    top: "27.27%",
    right: "11.47%",
    bottom: "27.27%",
    left: "83.2%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  barView: {
    position: "absolute",
    height: "35.71%",
    width: "17.39%",
    top: "223.81%",
    right: "-1613.04%",
    bottom: "-159.52%",
    left: "1695.65%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView1: {
    position: "absolute",
    height: "54.76%",
    width: "17.39%",
    top: "204.76%",
    right: "-1640.58%",
    bottom: "-159.52%",
    left: "1723.19%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView2: {
    position: "absolute",
    height: "78.57%",
    width: "17.39%",
    top: "180.95%",
    right: "-1668.12%",
    bottom: "-159.52%",
    left: "1750.72%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView3: {
    position: "absolute",
    height: "100%",
    width: "17.39%",
    top: "159.52%",
    right: "-1695.65%",
    bottom: "-159.52%",
    left: "1778.26%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  signalView: {
    position: "relative",
    backgroundColor: "#fff",
    width: 17.25,
    height: 10.5,
  },
  statusBarService: {
    position: "absolute",
    height: "23.86%",
    width: "4.6%",
    top: "38.07%",
    right: "17.4%",
    bottom: "38.07%",
    left: "78%",
  },
  boundsView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  locationIcon: {
    position: "absolute",
    height: "65.63%",
    width: "65.63%",
    top: "12.5%",
    right: "18.75%",
    bottom: "21.88%",
    left: "15.63%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarLocation: {
    position: "absolute",
    height: "80%",
    width: "28.07%",
    top: "10%",
    right: "0.88%",
    bottom: "10%",
    left: "71.05%",
  },
  text: {
    position: "absolute",
    transform: [
      {
        translateY: -10,
      },
    ],
    width: "61.4%",
    top: "50%",
    right: "32.46%",
    left: "6.14%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "SF Pro Display",
    color: "#fff",
    textAlign: "center",
  },
  timeView: {
    position: "absolute",
    height: "45.45%",
    width: "15.2%",
    top: "27.27%",
    right: "80.8%",
    bottom: "27.27%",
    left: "4%",
    overflow: "hidden",
  },
  systemStatusBarLight: {
    position: "absolute",
    height: "5.42%",
    width: "100%",
    top: "0%",
    right: "1.87%",
    bottom: "94.58%",
    left: "-1.87%",
  },
  appleLaunchesIOS16: {
    position: "absolute",
    top: 289,
    left: 59,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    backgroundColor: "#4236d1",
    width: 30,
    height: 3,
  },
  rectangleView4: {
    position: "absolute",
    top: 4.8,
    left: 8.4,
    backgroundColor: "#4236d1",
    width: 21.6,
    height: 3,
  },
  rectangleView5: {
    position: "absolute",
    top: 9.6,
    left: 18,
    backgroundColor: "#4236d1",
    width: 12,
    height: 3,
  },
  groupView: {
    position: "absolute",
    top: 293,
    left: 16,
    width: 30,
    height: 12.6,
  },
  rectangleView6: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 7.21,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 0.5,
  },
  icon: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 12.01,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView1: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon: {
    position: "absolute",
    top: 26.91,
    left: 0,
    width: 39.16,
    height: 10.09,
  },
  vanguardText: {
    position: "absolute",
    top: 29.55,
    left: 8.23,
    fontSize: 4.81,
    letterSpacing: -0.06,
    lineHeight: 4.81,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView2: {
    position: "absolute",
    height: "4.56%",
    width: "10.51%",
    top: "34.36%",
    right: "4.43%",
    bottom: "61.08%",
    left: "85.07%",
  },
  vuesaxtwotonearchiveTickIcon: {
    position: "absolute",
    top: 230,
    left: 17,
    width: 24,
    height: 24,
  },
  relatedNewsText: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  appleLaunchesIOS161: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView3: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView7: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView4: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView5: {
    position: "absolute",
    top: 35,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS162: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate1: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp1: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView6: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView8: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon1: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView7: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView8: {
    position: "absolute",
    top: 141,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS163: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate2: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp2: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView9: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView9: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon2: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView10: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView11: {
    position: "absolute",
    top: 247,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS164: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate3: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp3: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView12: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView10: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon3: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView13: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView14: {
    position: "absolute",
    top: 353,
    left: 0,
    width: 323,
    height: 90,
  },
  groupView15: {
    position: "absolute",
    top: 965,
    left: 10,
    width: 323,
    height: 443,
  },
  applesLatestAnnouncement: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  manyPeopleExcited: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  launchOfThe: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  butIfOwning: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  reallyBeenYour: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  someGoodNews: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  wheneverTheLatest: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theOlderModels: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  kindaTheSame: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  worthOnlyPennies: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  oneLaunchesThe: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  onSeptember16: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  opensInNew: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  yearsIPhone13: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  text1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  ifYouDidnt: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  heresHowThe: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  comparesopensInNew: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theLatestIPhone: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  opensInNew1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  bigOneAnnouncing: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  asWellAs: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  forTheIPhone: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  a48MPCameraopens: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  a65Larger: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  iPhone13Pro: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  asAnAdvanced: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  anAdditional2x: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  text2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  applesLatestAnnouncementHa: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 30,
    fontWeight: "500",
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
    width: 343,
    height: 1437,
  },
  minAgoText: {
    position: "absolute",
    top: 1063,
    left: 290,
    fontSize: 10,
    letterSpacing: -0.24,
    lineHeight: 30,
    fontFamily: "DM Sans",
    color: "#b7b7b7",
    textAlign: "left",
  },
  minAgoText1: {
    position: "absolute",
    top: 1170,
    left: 290,
    fontSize: 10,
    letterSpacing: -0.24,
    lineHeight: 30,
    fontFamily: "DM Sans",
    color: "#b7b7b7",
    textAlign: "left",
  },
  minAgoText2: {
    position: "absolute",
    top: 1276,
    left: 290,
    fontSize: 10,
    letterSpacing: -0.24,
    lineHeight: 30,
    fontFamily: "DM Sans",
    color: "#b7b7b7",
    textAlign: "left",
  },
  minAgoText3: {
    position: "absolute",
    top: 1383,
    left: 290,
    fontSize: 10,
    letterSpacing: -0.24,
    lineHeight: 30,
    fontFamily: "DM Sans",
    color: "#b7b7b7",
    textAlign: "left",
  },
  rectangleView11: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#3a3a3a",
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    width: 246,
    height: 100,
  },
  fluentnext28FilledIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  vectorIcon: {
    position: "absolute",
    height: "87.5%",
    width: "87.5%",
    top: "6.25%",
    right: "6.25%",
    bottom: "6.25%",
    left: "6.25%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectangleView12: {
    position: "absolute",
    height: "12.3%",
    width: "24.61%",
    top: "92.48%",
    right: "-20.12%",
    bottom: "-4.79%",
    left: "95.51%",
    borderRadius: 20,
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 40,
    elevation: 40,
    shadowOpacity: 1,
    display: "none",
  },
  antDesignpauseCircleFilledView: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  fluentnext28FilledIcon1: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  frameView: {
    position: "absolute",
    top: 53,
    left: 62,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  rectangleView13: {
    position: "absolute",
    top: 6,
    left: 28,
    backgroundColor: "#d9d9d9",
    width: 180,
    height: 3,
  },
  rectangleView14: {
    position: "absolute",
    top: 6,
    left: 28,
    backgroundColor: "#7168dc",
    width: 87,
    height: 3,
  },
  text3: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 11,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  text4: {
    position: "absolute",
    top: 0,
    left: 213,
    fontSize: 11,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  groupView16: {
    position: "absolute",
    top: 28,
    left: 5,
    width: 236,
    height: 14,
  },
  ellipseIcon: {
    position: "absolute",
    top: 30,
    left: 112,
    width: 10,
    height: 10,
  },
  icon1: {
    width: 20,
    height: 20,
  },
  tablerarrowsDiagonalMinimizPressable: {
    position: "absolute",
    left: 5,
    top: 75,
  },
  groupView17: {
    position: "absolute",
    top: 331,
    left: 44,
    width: 246,
    height: 100,
  },
  frameView1: {
    position: "absolute",
    top: 322,
    left: 16,
    width: 343,
    height: 485,
  },
  antDesignplayCircleTwotoneIcon: {
    position: "absolute",
    top: 0,
    left: 41,
    width: 24,
    height: 24,
  },
  readText: {
    position: "absolute",
    top: 3,
    left: 0,
    fontSize: 14,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  groupPressable: {
    position: "absolute",
    top: 230,
    left: 84,
    width: 65,
    height: 24,
  },
  icon2: {
    width: 24,
    height: 24,
  },
  biarrowLeftCirclePressable: {
    position: "absolute",
    left: 16,
    top: 48,
  },
  readModeView: {
    position: "relative",
    backgroundColor: "#0d0d0d",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default ReadMode;
