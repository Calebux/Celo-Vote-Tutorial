import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const ChooseNewsSource = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.chooseNewsSource}>
      <View style={styles.systemStatusBarLight}>
        <View style={styles.rectangleView} />
        <Image
          style={styles.cover1Icon}
          resizeMode="cover"
          source={require("../assets/cover-1.png")}
        />
        <View style={styles.rectangleView1} />
        <View style={styles.containerView} />
        <View style={styles.rectangleView2} />
        <Image
          style={styles.statusBarBattery}
          resizeMode="cover"
          source={require("../assets/status-bar--battery.png")}
        />
        <Image
          style={styles.statusBarWiFi}
          resizeMode="cover"
          source={require("../assets/status-bar--wifi.png")}
        />
        <View style={styles.statusBarService}>
          <View style={styles.signalView}>
            <View style={styles.barView} />
            <View style={styles.barView1} />
            <View style={styles.barView2} />
            <View style={styles.barView3} />
          </View>
        </View>
        <View style={styles.timeView}>
          <View style={styles.statusBarLocation}>
            <View style={styles.boundsView} />
            <Image
              style={styles.locationIcon}
              resizeMode="cover"
              source={require("../assets/location.png")}
            />
          </View>
          <Text style={styles.text}>12:22</Text>
        </View>
      </View>
      <Text style={styles.chooseNewsText}>{`Choose News `}</Text>
      <Text style={styles.selectText}>Select :</Text>
      <View style={styles.frameView}>
        <View style={styles.groupView36}>
          <View style={styles.groupView1}>
            <View style={styles.groupView}>
              <View style={styles.rectangleView3} />
              <Image
                style={styles.icon}
                resizeMode="cover"
                source={require("../assets/521-12.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.vanguardText}>Vanguard</Text>
          </View>
          <View style={styles.groupView3}>
            <View style={styles.groupView2}>
              <View style={styles.rectangleView4} />
              <Image
                style={styles.icon1}
                resizeMode="cover"
                source={require("../assets/5329267-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon1}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.punchText}>Punch</Text>
          </View>
          <View style={styles.groupView5}>
            <View style={styles.groupView4}>
              <View style={styles.rectangleView5} />
              <Image
                style={styles.icon2}
                resizeMode="cover"
                source={require("../assets/5319256-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon2}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.heraldText}>Herald</Text>
          </View>
          <View style={styles.groupView7}>
            <View style={styles.groupView6}>
              <View style={styles.rectangleView6} />
              <Image
                style={styles.icon3}
                resizeMode="cover"
                source={require("../assets/4342870-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon3}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.channelsText}>Channels</Text>
          </View>
          <View style={styles.groupView9}>
            <View style={styles.groupView8}>
              <View style={styles.rectangleView7} />
              <Image
                style={styles.icon4}
                resizeMode="cover"
                source={require("../assets/952896-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon4}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.saharaText}>Sahara</Text>
          </View>
          <View style={styles.groupView11}>
            <View style={styles.groupView10}>
              <View style={styles.rectangleView8} />
              <Image
                style={styles.icon5}
                resizeMode="cover"
                source={require("../assets/4552311-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon5}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.punchText1}>Punch</Text>
          </View>
          <View style={styles.groupView13}>
            <View style={styles.groupView12}>
              <View style={styles.rectangleView9} />
              <Image
                style={styles.icon6}
                resizeMode="cover"
                source={require("../assets/952242-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon6}
              resizeMode="cover"
              source={require("../assets/rectangle-72.png")}
            />
            <Text style={styles.dailyPostText}>Daily Post</Text>
          </View>
          <View style={styles.groupView15}>
            <View style={styles.groupView14}>
              <View style={styles.rectangleView10} />
              <Image
                style={styles.icon7}
                resizeMode="cover"
                source={require("../assets/1731669-1.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon7}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.channelsText1}>Channels</Text>
          </View>
          <View style={styles.groupView17}>
            <View style={styles.groupView16}>
              <View style={styles.rectangleView11} />
              <Image
                style={styles.icon8}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon8}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.saharaText1}>Sahara</Text>
          </View>
          <View style={styles.groupView19}>
            <View style={styles.groupView18}>
              <View style={styles.rectangleView12} />
              <Image
                style={styles.icon9}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon9}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.punchText2}>Punch</Text>
          </View>
          <View style={styles.groupView21}>
            <View style={styles.groupView20}>
              <View style={styles.rectangleView13} />
              <Image
                style={styles.icon10}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon10}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.punchText3}>Punch</Text>
          </View>
          <View style={styles.groupView23}>
            <View style={styles.groupView22}>
              <View style={styles.rectangleView14} />
              <Image
                style={styles.icon11}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon11}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.punchText4}>Punch</Text>
          </View>
          <View style={styles.groupView25}>
            <View style={styles.groupView24}>
              <View style={styles.rectangleView15} />
              <Image
                style={styles.icon12}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon12}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.punchText5}>Punch</Text>
          </View>
          <View style={styles.groupView27}>
            <View style={styles.groupView26}>
              <View style={styles.rectangleView16} />
              <Image
                style={styles.icon13}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon13}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.dailyPostText1}>Daily Post</Text>
          </View>
          <View style={styles.groupView29}>
            <View style={styles.groupView28}>
              <View style={styles.rectangleView17} />
              <Image
                style={styles.icon14}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon14}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.channelsText2}>Channels</Text>
          </View>
          <View style={styles.groupView31}>
            <View style={styles.groupView30}>
              <View style={styles.rectangleView18} />
              <Image
                style={styles.icon15}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon15}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.channelsText3}>Channels</Text>
          </View>
          <View style={styles.groupView33}>
            <View style={styles.groupView32}>
              <View style={styles.rectangleView19} />
              <Image
                style={styles.icon16}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon16}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.channelsText4}>Channels</Text>
          </View>
          <View style={styles.groupView35}>
            <View style={styles.groupView34}>
              <View style={styles.rectangleView20} />
              <Image
                style={styles.icon17}
                resizeMode="cover"
                source={require("../assets/952896-11.png")}
              />
            </View>
            <Image
              style={styles.rectangleIcon17}
              resizeMode="cover"
              source={require("../assets/rectangle-77.png")}
            />
            <Text style={styles.channelsText5}>Channels</Text>
          </View>
        </View>
      </View>
      <View style={styles.groupView37}>
        <Pressable
          style={styles.rectanglePressable}
          onPress={() => navigation.navigate("Home1")}
        />
        <Text style={styles.saveText}>Save</Text>
      </View>
      <Image
        style={styles.bxselectMultipleIcon}
        resizeMode="cover"
        source={require("../assets/bxselectmultiple.png")}
      />
      <Text style={styles.text1}>12</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleView: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "#1c1a29",
    display: "none",
  },
  cover1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 812,
    display: "none",
  },
  rectangleView1: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "rgba(23, 20, 36, 0.85)",
    display: "none",
  },
  containerView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#040404",
    display: "none",
    opacity: 0,
  },
  rectangleView2: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  statusBarBattery: {
    position: "absolute",
    height: "45.45%",
    width: "7.2%",
    top: "27.27%",
    right: "4%",
    bottom: "27.27%",
    left: "88.8%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarWiFi: {
    position: "absolute",
    height: "45.45%",
    width: "5.33%",
    top: "27.27%",
    right: "11.47%",
    bottom: "27.27%",
    left: "83.2%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  barView: {
    position: "absolute",
    height: "35.71%",
    width: "17.39%",
    top: "223.81%",
    right: "-1613.04%",
    bottom: "-159.52%",
    left: "1695.65%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView1: {
    position: "absolute",
    height: "54.76%",
    width: "17.39%",
    top: "204.76%",
    right: "-1640.58%",
    bottom: "-159.52%",
    left: "1723.19%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView2: {
    position: "absolute",
    height: "78.57%",
    width: "17.39%",
    top: "180.95%",
    right: "-1668.12%",
    bottom: "-159.52%",
    left: "1750.72%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView3: {
    position: "absolute",
    height: "100%",
    width: "17.39%",
    top: "159.52%",
    right: "-1695.65%",
    bottom: "-159.52%",
    left: "1778.26%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  signalView: {
    position: "relative",
    backgroundColor: "#fff",
    width: 17.25,
    height: 10.5,
  },
  statusBarService: {
    position: "absolute",
    height: "23.86%",
    width: "4.6%",
    top: "38.07%",
    right: "17.4%",
    bottom: "38.07%",
    left: "78%",
  },
  boundsView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  locationIcon: {
    position: "absolute",
    height: "65.63%",
    width: "65.63%",
    top: "12.5%",
    right: "18.75%",
    bottom: "21.88%",
    left: "15.63%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarLocation: {
    position: "absolute",
    height: "80%",
    width: "28.07%",
    top: "10%",
    right: "0.88%",
    bottom: "10%",
    left: "71.05%",
  },
  text: {
    position: "absolute",
    transform: [
      {
        translateY: -10,
      },
    ],
    width: "61.4%",
    top: "50%",
    right: "32.46%",
    left: "6.14%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "SF Pro Display",
    color: "#fff",
    textAlign: "center",
  },
  timeView: {
    position: "absolute",
    height: "45.45%",
    width: "15.2%",
    top: "27.27%",
    right: "80.8%",
    bottom: "27.27%",
    left: "4%",
    overflow: "hidden",
  },
  systemStatusBarLight: {
    position: "absolute",
    height: "5.42%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "94.58%",
    left: "0%",
  },
  chooseNewsText: {
    position: "absolute",
    height: "2.46%",
    width: "40.53%",
    top: "8%",
    right: "29.6%",
    bottom: "89.53%",
    left: "29.87%",
    fontSize: 24,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  selectText: {
    position: "absolute",
    height: "2.46%",
    width: "17.07%",
    top: "12.19%",
    right: "78.67%",
    bottom: "85.34%",
    left: "4.27%",
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  rectangleView3: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 50,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  vanguardText: {
    position: "absolute",
    top: 123,
    left: 37,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView1: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "0%",
    right: "51.04%",
    bottom: "89.83%",
    left: "0%",
  },
  rectangleView4: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon1: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView2: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon1: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView3: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "11.23%",
    right: "51.04%",
    bottom: "78.6%",
    left: "0%",
  },
  rectangleView5: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon2: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView4: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon2: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  heraldText: {
    position: "absolute",
    top: 123,
    left: 52,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView5: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "0%",
    right: "0%",
    bottom: "89.83%",
    left: "51.04%",
  },
  rectangleView6: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon3: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView6: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon3: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  channelsText: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView7: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "11.23%",
    right: "0%",
    bottom: "78.6%",
    left: "51.04%",
  },
  rectangleView7: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon4: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView8: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon4: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  saharaText: {
    position: "absolute",
    top: 123,
    left: 49,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView9: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "22.46%",
    right: "51.04%",
    bottom: "67.37%",
    left: "0%",
  },
  rectangleView8: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon5: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView10: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon5: {
    position: "absolute",
    top: 622,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText1: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView11: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "33.69%",
    right: "51.04%",
    bottom: "56.14%",
    left: "0%",
  },
  rectangleView9: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon6: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView12: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon6: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  dailyPostText: {
    position: "absolute",
    top: 123,
    left: 36,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView13: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "22.46%",
    right: "0%",
    bottom: "67.37%",
    left: "51.04%",
  },
  rectangleView10: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon7: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView14: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon7: {
    position: "absolute",
    top: 622,
    left: 171,
    width: 163,
    height: 42,
  },
  channelsText1: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView15: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "33.69%",
    right: "0%",
    bottom: "56.14%",
    left: "51.04%",
  },
  rectangleView11: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon8: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView16: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon8: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  saharaText1: {
    position: "absolute",
    top: 123,
    left: 49,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView17: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "44.91%",
    right: "51.04%",
    bottom: "44.91%",
    left: "0%",
  },
  rectangleView12: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon9: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView18: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon9: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText2: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView19: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "56.14%",
    right: "51.04%",
    bottom: "33.69%",
    left: "0%",
  },
  rectangleView13: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon10: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView20: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon10: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText3: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView21: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "78.6%",
    right: "51.04%",
    bottom: "11.23%",
    left: "0%",
  },
  rectangleView14: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon11: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView22: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon11: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText4: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView23: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "67.37%",
    right: "51.04%",
    bottom: "22.46%",
    left: "0%",
  },
  rectangleView15: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon12: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.3%",
    right: "1.23%",
    bottom: "2.6%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView24: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon12: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  punchText5: {
    position: "absolute",
    top: 123,
    left: 54,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView25: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "89.83%",
    right: "51.04%",
    bottom: "0%",
    left: "0%",
  },
  rectangleView16: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon13: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView26: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon13: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  dailyPostText1: {
    position: "absolute",
    top: 123,
    left: 36,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView27: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "44.91%",
    right: "0%",
    bottom: "44.91%",
    left: "51.04%",
  },
  rectangleView17: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon14: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView28: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon14: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  channelsText2: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView29: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "56.14%",
    right: "0%",
    bottom: "33.69%",
    left: "51.04%",
  },
  rectangleView18: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon15: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView30: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon15: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  channelsText3: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView31: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "78.6%",
    right: "0%",
    bottom: "11.23%",
    left: "51.04%",
  },
  rectangleView19: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon16: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView32: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon16: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  channelsText4: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView33: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "67.37%",
    right: "0%",
    bottom: "22.46%",
    left: "51.04%",
  },
  rectangleView20: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 30,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "rgba(58, 58, 58, 0.3)",
    borderWidth: 2,
  },
  icon17: {
    position: "absolute",
    height: "96.1%",
    width: "96.93%",
    top: "1.95%",
    right: "1.23%",
    bottom: "1.95%",
    left: "1.84%",
    borderRadius: 30,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  groupView34: {
    position: "absolute",
    height: "100%",
    width: "99.39%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0.61%",
  },
  rectangleIcon17: {
    position: "absolute",
    top: 112,
    left: 0,
    width: 163,
    height: 42,
  },
  channelsText5: {
    position: "absolute",
    top: 123,
    left: 40,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  groupView35: {
    position: "absolute",
    height: "10.17%",
    width: "48.96%",
    top: "89.83%",
    right: "0%",
    bottom: "0%",
    left: "51.04%",
  },
  groupView36: {
    position: "absolute",
    height: "262.85%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-162.85%",
    left: "0%",
  },
  frameView: {
    position: "absolute",
    top: 138,
    left: 20,
    width: 335,
    height: 576,
  },
  rectanglePressable: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#7168dc",
    width: 343,
    height: 65,
  },
  saveText: {
    position: "absolute",
    top: 24,
    left: 136,
    fontSize: 30,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "900",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  groupView37: {
    position: "absolute",
    top: 714,
    left: 15,
    width: 343,
    height: 65,
  },
  bxselectMultipleIcon: {
    position: "absolute",
    top: 99,
    left: 111,
    width: 20,
    height: 20,
  },
  text1: {
    position: "absolute",
    top: 98,
    left: 82,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  chooseNewsSource: {
    position: "relative",
    backgroundColor: "#0d0d0d",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default ChooseNewsSource;
