import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Home1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeView}>
      <View style={styles.systemStatusBarLight}>
        <View style={styles.rectangleView} />
        <Image
          style={styles.cover1Icon}
          resizeMode="cover"
          source={require("../assets/cover-1.png")}
        />
        <View style={styles.rectangleView1} />
        <View style={styles.containerView} />
        <View style={styles.rectangleView2} />
        <Image
          style={styles.statusBarBattery}
          resizeMode="cover"
          source={require("../assets/status-bar--battery.png")}
        />
        <Image
          style={styles.statusBarWiFi}
          resizeMode="cover"
          source={require("../assets/status-bar--wifi.png")}
        />
        <View style={styles.statusBarService}>
          <View style={styles.signalView}>
            <View style={styles.barView} />
            <View style={styles.barView1} />
            <View style={styles.barView2} />
            <View style={styles.barView3} />
          </View>
        </View>
        <View style={styles.timeView}>
          <View style={styles.statusBarLocation}>
            <View style={styles.boundsView} />
            <Image
              style={styles.locationIcon}
              resizeMode="cover"
              source={require("../assets/location.png")}
            />
          </View>
          <Text style={styles.text}>12:22</Text>
        </View>
      </View>
      <View style={styles.frameView}>
        <View style={styles.groupView}>
          <Text style={styles.trendingText}>Trending</Text>
          <Image
            style={styles.ellipseIcon}
            resizeMode="cover"
            source={require("../assets/ellipse-2.png")}
          />
        </View>
        <Pressable
          style={[styles.groupPressable, styles.ml21]}
          onPress={() => navigation.navigate("Home")}
        >
          <Text style={styles.politicsText}>Politics</Text>
          <Image
            style={styles.ellipseIcon1}
            resizeMode="cover"
            source={require("../assets/ellipse-3.png")}
          />
        </Pressable>
        <View style={[styles.groupView1, styles.ml21]}>
          <Text style={styles.fashionText}>Fashion</Text>
          <Image
            style={styles.ellipseIcon2}
            resizeMode="cover"
            source={require("../assets/ellipse-4.png")}
          />
        </View>
        <View style={[styles.groupView2, styles.ml21]}>
          <Text style={styles.businessText}>Business</Text>
          <Image
            style={styles.ellipseIcon3}
            resizeMode="cover"
            source={require("../assets/ellipse-5.png")}
          />
        </View>
        <View style={[styles.groupView3, styles.ml21]}>
          <Text style={styles.sportsText}>Sports</Text>
          <Image
            style={styles.ellipseIcon4}
            resizeMode="cover"
            source={require("../assets/ellipse-6.png")}
          />
        </View>
        <View style={[styles.groupView4, styles.ml21]}>
          <Text style={styles.localText}>Local</Text>
          <Image
            style={styles.ellipseIcon5}
            resizeMode="cover"
            source={require("../assets/ellipse-8.png")}
          />
        </View>
        <View style={[styles.groupView5, styles.ml21]}>
          <Text style={styles.musicText}>Music</Text>
          <Image
            style={styles.ellipseIcon6}
            resizeMode="cover"
            source={require("../assets/ellipse-8.png")}
          />
        </View>
        <View style={[styles.groupView6, styles.ml21]}>
          <Text style={styles.enviromentText}>Enviroment</Text>
          <Image
            style={styles.ellipseIcon7}
            resizeMode="cover"
            source={require("../assets/ellipse-8.png")}
          />
        </View>
      </View>
      <Text style={styles.trendingText1}>Trending</Text>
      <View style={styles.frameView1}>
        <Pressable
          style={styles.groupPressable1}
          onPress={() => navigation.navigate("ReadMode1")}
        >
          <View style={styles.groupView7}>
            <Text style={styles.appleLaunchesIOS16}>Apple Launches IOS 16</Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp}>
              <Text
                style={styles.iPadOS16Is}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView8}>
            <View style={styles.rectangleView3} />
            <Image
              style={styles.download1Icon}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </Pressable>
        <View style={styles.groupView11}>
          <View style={styles.groupView9}>
            <Text style={styles.appleLaunchesIOS161}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp1}>
              <Text
                style={styles.iPadOS16Is1}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease1}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate1}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView10}>
            <View style={styles.rectangleView4} />
            <Image
              style={styles.download1Icon1}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView14}>
          <View style={styles.groupView12}>
            <Text style={styles.appleLaunchesIOS162}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp2}>
              <Text
                style={styles.iPadOS16Is2}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease2}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate2}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView13}>
            <View style={styles.rectangleView5} />
            <Image
              style={styles.download1Icon2}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView17}>
          <View style={styles.groupView15}>
            <Text style={styles.appleLaunchesIOS163}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp3}>
              <Text
                style={styles.iPadOS16Is3}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease3}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate3}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView16}>
            <View style={styles.rectangleView6} />
            <Image
              style={styles.download1Icon3}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
        <View style={styles.groupView20}>
          <View style={styles.groupView18}>
            <Text style={styles.appleLaunchesIOS164}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp4}>
              <Text
                style={styles.iPadOS16Is4}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease4}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate4}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView19}>
            <View style={styles.rectangleView7} />
            <Image
              style={styles.download1Icon4}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
        <View style={styles.groupView23}>
          <View style={styles.groupView21}>
            <Text style={styles.appleLaunchesIOS165}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp5}>
              <Text
                style={styles.iPadOS16Is5}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease5}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate5}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView22}>
            <View style={styles.rectangleView8} />
            <Image
              style={styles.download1Icon5}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
        <View style={styles.groupView26}>
          <View style={styles.groupView24}>
            <Text style={styles.appleLaunchesIOS166}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp6}>
              <Text
                style={styles.iPadOS16Is6}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease6}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate6}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView25}>
            <View style={styles.rectangleView9} />
            <Image
              style={styles.download1Icon6}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
        <View style={styles.groupView29}>
          <View style={styles.groupView27}>
            <Text style={styles.appleLaunchesIOS167}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp7}>
              <Text
                style={styles.iPadOS16Is7}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease7}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate7}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView28}>
            <View style={styles.rectangleView10} />
            <Image
              style={styles.download1Icon7}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
      </View>
      <View style={styles.frameView3}>
        <View style={styles.frameView2}>
          <Image
            style={styles.vuesaxtwotonehome2Icon}
            resizeMode="cover"
            source={require("../assets/vuesaxtwotonehome24.png")}
          />
          <Pressable
            style={[styles.vuesaxtwotonesearchNormalPressable, styles.ml71]}
            onPress={() => navigation.navigate("Search")}
          >
            <Image
              style={styles.icon}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonesearchnormal.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.vuesaxtwotonearchiveTickPressable, styles.ml71]}
            onPress={() => navigation.navigate("Saved")}
          >
            <Image
              style={styles.icon1}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonearchivetick.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.vuesaxtwotonesetting2Pressable, styles.ml71]}
            onPress={() => navigation.navigate("Settings1")}
          >
            <Image
              style={styles.icon2}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonesetting2.png")}
            />
          </Pressable>
        </View>
      </View>
      <View style={styles.frameView4}>
        <View style={styles.groupView31}>
          <View style={styles.groupView30}>
            <Pressable
              style={styles.rectanglePressable}
              onPress={() => navigation.navigate("ReadMode1")}
            >
              <Image
                style={styles.icon3}
                resizeMode="cover"
                source={require("../assets/rectangle-10.png")}
              />
            </Pressable>
            <Image
              style={styles.rectangleIcon}
              resizeMode="cover"
              source={require("../assets/rectangle-15.png")}
            />
            <Image
              style={styles.rectangleIcon1}
              resizeMode="cover"
              source={require("../assets/rectangle-13.png")}
            />
            <Image
              style={styles.rectangleIcon2}
              resizeMode="cover"
              source={require("../assets/rectangle-13.png")}
            />
            <Image
              style={styles.rectangleIcon3}
              resizeMode="cover"
              source={require("../assets/rectangle-13.png")}
            />
            <Image
              style={styles.rectangleIcon4}
              resizeMode="cover"
              source={require("../assets/rectangle-13.png")}
            />
            <Text style={styles.appleLaunchesIOS168}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.newHousesRealesed}>New Houses Realesed</Text>
            <Text style={styles.newText}>New</Text>
            <Text style={styles.newText1}>New</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ml21: {
    marginLeft: 21,
  },
  ml71: {
    marginLeft: 71,
  },
  rectangleView: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "#1c1a29",
    display: "none",
  },
  cover1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 812,
    display: "none",
  },
  rectangleView1: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "rgba(23, 20, 36, 0.85)",
    display: "none",
  },
  containerView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#040404",
    display: "none",
    opacity: 0,
  },
  rectangleView2: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  statusBarBattery: {
    position: "absolute",
    height: "45.45%",
    width: "7.2%",
    top: "27.27%",
    right: "4%",
    bottom: "27.27%",
    left: "88.8%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarWiFi: {
    position: "absolute",
    height: "45.45%",
    width: "5.33%",
    top: "27.27%",
    right: "11.47%",
    bottom: "27.27%",
    left: "83.2%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  barView: {
    position: "absolute",
    height: "35.71%",
    width: "17.39%",
    top: "223.81%",
    right: "-1613.04%",
    bottom: "-159.52%",
    left: "1695.65%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView1: {
    position: "absolute",
    height: "54.76%",
    width: "17.39%",
    top: "204.76%",
    right: "-1640.58%",
    bottom: "-159.52%",
    left: "1723.19%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView2: {
    position: "absolute",
    height: "78.57%",
    width: "17.39%",
    top: "180.95%",
    right: "-1668.12%",
    bottom: "-159.52%",
    left: "1750.72%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView3: {
    position: "absolute",
    height: "100%",
    width: "17.39%",
    top: "159.52%",
    right: "-1695.65%",
    bottom: "-159.52%",
    left: "1778.26%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  signalView: {
    position: "relative",
    backgroundColor: "#fff",
    width: 17.25,
    height: 10.5,
  },
  statusBarService: {
    position: "absolute",
    height: "23.86%",
    width: "4.6%",
    top: "38.07%",
    right: "17.4%",
    bottom: "38.07%",
    left: "78%",
  },
  boundsView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  locationIcon: {
    position: "absolute",
    height: "65.63%",
    width: "65.63%",
    top: "12.5%",
    right: "18.75%",
    bottom: "21.88%",
    left: "15.63%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarLocation: {
    position: "absolute",
    height: "80%",
    width: "28.07%",
    top: "10%",
    right: "0.88%",
    bottom: "10%",
    left: "71.05%",
  },
  text: {
    position: "absolute",
    transform: [
      {
        translateY: -10,
      },
    ],
    width: "61.4%",
    top: "50%",
    right: "32.46%",
    left: "6.14%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "SF Pro Display",
    color: "#fff",
    textAlign: "center",
  },
  timeView: {
    position: "absolute",
    height: "45.45%",
    width: "15.2%",
    top: "27.27%",
    right: "80.8%",
    bottom: "27.27%",
    left: "4%",
    overflow: "hidden",
  },
  systemStatusBarLight: {
    position: "absolute",
    height: "5.42%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "94.58%",
    left: "0%",
  },
  trendingText: {
    position: "absolute",
    height: "22.73%",
    width: "96.77%",
    top: "77.27%",
    right: "0%",
    bottom: "0%",
    left: "3.23%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 68,
    height: 68,
  },
  groupView: {
    position: "relative",
    width: 62,
    height: 88,
    flexShrink: 0,
  },
  politicsText: {
    position: "absolute",
    height: "22.73%",
    width: "81.67%",
    top: "77.27%",
    right: "11.67%",
    bottom: "0%",
    left: "6.67%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon1: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 68,
    height: 68,
  },
  groupPressable: {
    position: "relative",
    width: 60,
    height: 88,
    flexShrink: 0,
  },
  fashionText: {
    position: "absolute",
    height: "22.73%",
    width: "90%",
    top: "77.27%",
    right: "5%",
    bottom: "0%",
    left: "5%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon2: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 68,
    height: 68,
  },
  groupView1: {
    position: "relative",
    width: 60,
    height: 88,
    flexShrink: 0,
  },
  businessText: {
    position: "absolute",
    height: "22.73%",
    width: "95.31%",
    top: "77.27%",
    right: "0%",
    bottom: "0%",
    left: "4.69%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon3: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 68,
    height: 68,
  },
  groupView2: {
    position: "relative",
    width: 64,
    height: 88,
    flexShrink: 0,
  },
  sportsText: {
    position: "absolute",
    height: "22.73%",
    width: "76.67%",
    top: "77.27%",
    right: "13.33%",
    bottom: "0%",
    left: "10%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon4: {
    position: "absolute",
    top: -4,
    left: -4,
    width: 60,
    height: 68,
  },
  groupView3: {
    position: "relative",
    width: 60,
    height: 88,
    flexShrink: 0,
  },
  localText: {
    position: "absolute",
    height: "22.73%",
    width: "61.67%",
    top: "77.27%",
    right: "18.33%",
    bottom: "0%",
    left: "20%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon5: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 60,
    height: 60,
  },
  groupView4: {
    position: "relative",
    width: 60,
    height: 88,
    flexShrink: 0,
  },
  musicText: {
    position: "absolute",
    height: "22.73%",
    width: "66.67%",
    top: "77.27%",
    right: "16.67%",
    bottom: "0%",
    left: "16.67%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon6: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 60,
    height: 60,
  },
  groupView5: {
    position: "relative",
    width: 60,
    height: 88,
    flexShrink: 0,
  },
  enviromentText: {
    position: "absolute",
    height: "22.73%",
    width: "100%",
    top: "77.27%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  ellipseIcon7: {
    position: "absolute",
    top: 0,
    left: 7,
    width: 60,
    height: 60,
  },
  groupView6: {
    position: "relative",
    width: 78,
    height: 88,
    flexShrink: 0,
  },
  frameView: {
    position: "absolute",
    height: "7.39%",
    width: "95.73%",
    top: "8.74%",
    right: "0%",
    bottom: "83.87%",
    left: "4.27%",
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  trendingText1: {
    position: "absolute",
    top: 393,
    left: 16,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  appleLaunchesIOS16: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView7: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView8: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupPressable1: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS161: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate1: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp1: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView9: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon1: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView10: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView11: {
    position: "absolute",
    top: 106,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS162: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate2: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp2: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView12: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView5: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon2: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView13: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView14: {
    position: "absolute",
    top: 212,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS163: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate3: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp3: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView15: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView6: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon3: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView16: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView17: {
    position: "absolute",
    top: 318,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS164: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is4: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease4: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate4: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp4: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView18: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView7: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon4: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView19: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView20: {
    position: "absolute",
    top: 424,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS165: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is5: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease5: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate5: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp5: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView21: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView8: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon5: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView22: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView23: {
    position: "absolute",
    top: 530,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS166: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is6: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease6: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate6: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp6: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView24: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView9: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon6: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView25: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView26: {
    position: "absolute",
    top: 636,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS167: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  iPadOS16Is7: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease7: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate7: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp7: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#fff",
    textAlign: "left",
  },
  groupView27: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView10: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon7: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView28: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView29: {
    position: "absolute",
    top: 742,
    left: 0,
    width: 323,
    height: 90,
  },
  frameView1: {
    position: "absolute",
    top: 428,
    left: 17,
    width: 323,
    height: 300,
  },
  vuesaxtwotonehome2Icon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  vuesaxtwotonesearchNormalPressable: {
    position: "relative",
  },
  icon1: {
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  vuesaxtwotonearchiveTickPressable: {
    position: "relative",
  },
  icon2: {
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  vuesaxtwotonesetting2Pressable: {
    position: "relative",
  },
  frameView2: {
    position: "absolute",
    top: 24,
    left: 33,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  frameView3: {
    position: "absolute",
    height: "8.74%",
    width: "100%",
    top: "91.26%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#3a3a3a",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 30,
    elevation: 30,
    shadowOpacity: 1,
    overflow: "hidden",
  },
  icon3: {
    height: "100%",
    width: "16.06%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectanglePressable: {
    position: "absolute",
    left: "3.02%",
    top: "0%",
    right: "80.92%",
    bottom: "0%",
  },
  rectangleIcon: {
    position: "absolute",
    height: "100%",
    width: "16.06%",
    top: "0%",
    right: "67.15%",
    bottom: "0%",
    left: "16.79%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectangleIcon1: {
    position: "absolute",
    height: "100%",
    width: "16.06%",
    top: "0%",
    right: "53.39%",
    bottom: "0%",
    left: "30.55%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectangleIcon2: {
    position: "absolute",
    height: "100%",
    width: "16.06%",
    top: "0%",
    right: "36.6%",
    bottom: "0%",
    left: "47.34%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectangleIcon3: {
    position: "absolute",
    height: "100%",
    width: "16.06%",
    top: "0%",
    right: "19.81%",
    bottom: "0%",
    left: "64.13%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  rectangleIcon4: {
    position: "absolute",
    height: "100%",
    width: "16.06%",
    top: "0%",
    right: "3.02%",
    bottom: "0%",
    left: "80.92%",
    borderRadius: 10,
    maxWidth: "100%",
    maxHeight: "100%",
  },
  appleLaunchesIOS168: {
    position: "absolute",
    top: 151,
    left: 7,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "800",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  newHousesRealesed: {
    position: "absolute",
    top: 151,
    left: 313,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "800",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  newText: {
    position: "absolute",
    top: 18,
    left: 7,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "800",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  newText1: {
    position: "absolute",
    top: 18,
    left: 308,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "800",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  groupView30: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  groupView31: {
    position: "absolute",
    height: "100%",
    width: "476.53%",
    top: "0%",
    right: "-362.13%",
    bottom: "0%",
    left: "-14.4%",
  },
  frameView4: {
    position: "absolute",
    top: 187,
    left: 0,
    width: 375,
    height: 184,
  },
  homeView: {
    position: "relative",
    backgroundColor: "#0d0d0d",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Home1;
