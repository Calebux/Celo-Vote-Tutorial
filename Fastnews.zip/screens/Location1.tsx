import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Location1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.locationView}>
      <View style={styles.systemStatusBarLight}>
        <View style={styles.rectangleView} />
        <Image style={styles.cover1Icon} resizeMode="cover" />
        <View style={styles.rectangleView1} />
        <View style={styles.containerView} />
        <View style={styles.rectangleView2} />
        <Image
          style={styles.statusBarBattery}
          resizeMode="cover"
          source={require("../assets/status-bar--battery11.png")}
        />
        <Image
          style={styles.statusBarWiFi}
          resizeMode="cover"
          source={require("../assets/status-bar--wifi11.png")}
        />
        <View style={styles.statusBarService}>
          <View style={styles.signalView}>
            <View style={styles.barView} />
            <View style={styles.barView1} />
            <View style={styles.barView2} />
            <View style={styles.barView3} />
          </View>
        </View>
        <View style={styles.timeView}>
          <View style={styles.statusBarLocation}>
            <View style={styles.boundsView} />
            <Image
              style={styles.locationIcon}
              resizeMode="cover"
              source={require("../assets/location11.png")}
            />
          </View>
          <Text style={styles.text}>12:22</Text>
        </View>
      </View>
      <Text style={styles.locationText}>Location</Text>
      <View style={styles.groupView}>
        <View style={styles.rectangleView3} />
        <Text style={styles.nigeriaText}>Nigeria</Text>
        <Image
          style={styles.evaarrowDownFillIcon}
          resizeMode="cover"
          source={require("../assets/evaarrowdownfill1.png")}
        />
      </View>
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("ChooseNewsSource2")}
      />
      <Text style={styles.saveText}>Save</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleView: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "#1c1a29",
    display: "none",
  },
  cover1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 812,
    display: "none",
  },
  rectangleView1: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "rgba(23, 20, 36, 0.85)",
    display: "none",
  },
  containerView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#040404",
    display: "none",
    opacity: 0,
  },
  rectangleView2: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  statusBarBattery: {
    position: "absolute",
    height: "45.45%",
    width: "7.2%",
    top: "27.27%",
    right: "4%",
    bottom: "27.27%",
    left: "88.8%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarWiFi: {
    position: "absolute",
    height: "45.45%",
    width: "5.33%",
    top: "27.27%",
    right: "11.47%",
    bottom: "27.27%",
    left: "83.2%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  barView: {
    position: "absolute",
    height: "35.71%",
    width: "17.39%",
    top: "223.81%",
    right: "-1613.04%",
    bottom: "-159.52%",
    left: "1695.65%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView1: {
    position: "absolute",
    height: "54.76%",
    width: "17.39%",
    top: "204.76%",
    right: "-1640.58%",
    bottom: "-159.52%",
    left: "1723.19%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView2: {
    position: "absolute",
    height: "78.57%",
    width: "17.39%",
    top: "180.95%",
    right: "-1668.12%",
    bottom: "-159.52%",
    left: "1750.72%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView3: {
    position: "absolute",
    height: "100%",
    width: "17.39%",
    top: "159.52%",
    right: "-1695.65%",
    bottom: "-159.52%",
    left: "1778.26%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  signalView: {
    position: "relative",
    backgroundColor: "#000",
    width: 17.25,
    height: 10.5,
  },
  statusBarService: {
    position: "absolute",
    height: "23.86%",
    width: "4.6%",
    top: "38.07%",
    right: "17.4%",
    bottom: "38.07%",
    left: "78%",
  },
  boundsView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  locationIcon: {
    position: "absolute",
    height: "65.63%",
    width: "65.63%",
    top: "12.5%",
    right: "18.75%",
    bottom: "21.88%",
    left: "15.63%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarLocation: {
    position: "absolute",
    height: "80%",
    width: "28.07%",
    top: "10%",
    right: "0.88%",
    bottom: "10%",
    left: "71.05%",
  },
  text: {
    position: "absolute",
    transform: [
      {
        translateY: -10,
      },
    ],
    width: "61.4%",
    top: "50%",
    right: "32.46%",
    left: "6.14%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "SF Pro Display",
    color: "#000",
    textAlign: "center",
  },
  timeView: {
    position: "absolute",
    height: "45.45%",
    width: "15.2%",
    top: "27.27%",
    right: "80.8%",
    bottom: "27.27%",
    left: "4%",
    overflow: "hidden",
  },
  systemStatusBarLight: {
    position: "absolute",
    height: "5.42%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "94.58%",
    left: "0%",
  },
  locationText: {
    position: "absolute",
    transform: [
      {
        translateY: -341,
      },
    ],
    width: "25.33%",
    top: "50%",
    right: "37.33%",
    left: "37.33%",
    fontSize: 24,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#fff",
    borderStyle: "solid",
    borderColor: "#3a3a3a",
    borderWidth: 0.5,
    width: 321,
    height: 50,
  },
  nigeriaText: {
    position: "absolute",
    top: 15,
    left: 9,
    fontSize: 20,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  evaarrowDownFillIcon: {
    position: "absolute",
    top: 13,
    left: 287,
    width: 24,
    height: 24,
  },
  groupView: {
    position: "absolute",
    top: 105,
    left: 27,
    width: 321,
    height: 50,
  },
  rectanglePressable: {
    position: "absolute",
    top: 230,
    left: 16,
    borderRadius: 10,
    backgroundColor: "#7168dc",
    width: 343,
    height: 65,
  },
  saveText: {
    position: "absolute",
    top: 254,
    left: 152,
    fontSize: 30,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "900",
    fontFamily: "Mulish",
    color: "#fff",
    textAlign: "center",
  },
  locationView: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Location1;
