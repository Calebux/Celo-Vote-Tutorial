import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";

const Saved1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.savedView}>
      <View style={styles.systemStatusBarLight}>
        <View style={styles.rectangleView} />
        <Image
          style={styles.cover1Icon}
          resizeMode="cover"
          source={require("../assets/cover-1.png")}
        />
        <View style={styles.rectangleView1} />
        <View style={styles.containerView} />
        <View style={styles.rectangleView2} />
        <Image
          style={styles.statusBarBattery}
          resizeMode="cover"
          source={require("../assets/status-bar--battery11.png")}
        />
        <Image
          style={styles.statusBarWiFi}
          resizeMode="cover"
          source={require("../assets/status-bar--wifi11.png")}
        />
        <View style={styles.statusBarService}>
          <View style={styles.signalView}>
            <View style={styles.barView} />
            <View style={styles.barView1} />
            <View style={styles.barView2} />
            <View style={styles.barView3} />
          </View>
        </View>
        <View style={styles.timeView}>
          <View style={styles.statusBarLocation}>
            <View style={styles.boundsView} />
            <Image
              style={styles.locationIcon}
              resizeMode="cover"
              source={require("../assets/location11.png")}
            />
          </View>
          <Text style={styles.text}>12:22</Text>
        </View>
      </View>
      <Text style={styles.savedText}>Saved</Text>
      <View style={styles.frameView}>
        <View style={styles.groupView2}>
          <View style={styles.groupView}>
            <Text style={styles.appleLaunchesIOS16}>Apple Launches IOS 16</Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp}>
              <Text
                style={styles.iPadOS16Is}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView1}>
            <View style={styles.rectangleView3} />
            <Image
              style={styles.download1Icon}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView5}>
          <View style={styles.groupView3}>
            <Text style={styles.appleLaunchesIOS161}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp1}>
              <Text
                style={styles.iPadOS16Is1}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease1}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate1}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView4}>
            <View style={styles.rectangleView4} />
            <Image
              style={styles.download1Icon1}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView8}>
          <View style={styles.groupView6}>
            <Text style={styles.appleLaunchesIOS162}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp2}>
              <Text
                style={styles.iPadOS16Is2}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease2}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate2}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView7}>
            <View style={styles.rectangleView5} />
            <Image
              style={styles.download1Icon2}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView11}>
          <View style={styles.groupView9}>
            <Text style={styles.appleLaunchesIOS163}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp3}>
              <Text
                style={styles.iPadOS16Is3}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease3}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate3}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView10}>
            <View style={styles.rectangleView6} />
            <Image
              style={styles.download1Icon3}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView14}>
          <View style={styles.groupView12}>
            <Text style={styles.appleLaunchesIOS164}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp4}>
              <Text
                style={styles.iPadOS16Is4}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease4}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate4}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView13}>
            <View style={styles.rectangleView7} />
            <Image
              style={styles.download1Icon4}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView17}>
          <View style={styles.groupView15}>
            <Text style={styles.appleLaunchesIOS165}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp5}>
              <Text
                style={styles.iPadOS16Is5}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease5}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate5}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView16}>
            <View style={styles.rectangleView8} />
            <Image
              style={styles.download1Icon5}
              resizeMode="cover"
              source={require("../assets/download-1.png")}
            />
          </View>
        </View>
        <View style={styles.groupView20}>
          <View style={styles.groupView18}>
            <Text style={styles.appleLaunchesIOS166}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp6}>
              <Text
                style={styles.iPadOS16Is6}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease6}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate6}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView19}>
            <View style={styles.rectangleView9} />
            <Image
              style={styles.download1Icon6}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
        <View style={styles.groupView23}>
          <View style={styles.groupView21}>
            <Text style={styles.appleLaunchesIOS167}>
              Apple Launches IOS 16
            </Text>
            <Text style={styles.iPadOS16IsTheFourthAndUp7}>
              <Text
                style={styles.iPadOS16Is7}
              >{`iPadOS 16 is the fourth and `}</Text>
              <Text style={styles.upcomingMajorRelease7}>
                upcoming major release of
              </Text>
              <Text style={styles.theIPadOSOperate7}>the iPadOS operate</Text>
            </Text>
          </View>
          <View style={styles.groupView22}>
            <View style={styles.rectangleView10} />
            <Image
              style={styles.download1Icon7}
              resizeMode="cover"
              source={require("../assets/download-16.png")}
            />
          </View>
        </View>
      </View>
      <View style={styles.frameView2}>
        <View style={styles.frameView1}>
          <Pressable
            style={styles.vuesaxtwotonehome2Pressable}
            onPress={() => navigation.navigate("Home3")}
          >
            <Image
              style={styles.icon}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonehome28.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.vuesaxtwotonesearchNormalPressable, styles.ml71]}
            onPress={() => navigation.navigate("Search1")}
          >
            <Image
              style={styles.icon1}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonesearchnormal8.png")}
            />
          </Pressable>
          <Image
            style={[styles.vuesaxtwotonearchiveTickIcon, styles.ml71]}
            resizeMode="cover"
            source={require("../assets/vuesaxtwotonearchivetick10.png")}
          />
          <Pressable
            style={[styles.vuesaxtwotonesetting2Pressable, styles.ml71]}
            onPress={() => navigation.navigate("Settings3")}
          >
            <Image
              style={styles.icon2}
              resizeMode="cover"
              source={require("../assets/vuesaxtwotonesetting24.png")}
            />
          </Pressable>
        </View>
      </View>
      <View style={styles.groupView24}>
        <View style={styles.rectangleView11} />
        <Text style={styles.searchSavedNews}>Search saved news</Text>
        <Image
          style={styles.vuesaxtwotonesearchNormalIcon}
          resizeMode="cover"
          source={require("../assets/vuesaxtwotonesearchnormal11.png")}
        />
      </View>
      <Image
        style={styles.icbaselineKeyboardVoiceIcon}
        resizeMode="cover"
        source={require("../assets/icbaselinekeyboardvoice2.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  ml71: {
    marginLeft: 71,
  },
  rectangleView: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "#1c1a29",
    display: "none",
  },
  cover1Icon: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 375,
    height: 812,
    display: "none",
  },
  rectangleView1: {
    position: "absolute",
    height: "1845.45%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "-1745.45%",
    left: "0%",
    backgroundColor: "rgba(23, 20, 36, 0.85)",
    display: "none",
  },
  containerView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#040404",
    display: "none",
    opacity: 0,
  },
  rectangleView2: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  statusBarBattery: {
    position: "absolute",
    height: "45.45%",
    width: "7.2%",
    top: "27.27%",
    right: "4%",
    bottom: "27.27%",
    left: "88.8%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarWiFi: {
    position: "absolute",
    height: "45.45%",
    width: "5.33%",
    top: "27.27%",
    right: "11.47%",
    bottom: "27.27%",
    left: "83.2%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  barView: {
    position: "absolute",
    height: "35.71%",
    width: "17.39%",
    top: "223.81%",
    right: "-1613.04%",
    bottom: "-159.52%",
    left: "1695.65%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView1: {
    position: "absolute",
    height: "54.76%",
    width: "17.39%",
    top: "204.76%",
    right: "-1640.58%",
    bottom: "-159.52%",
    left: "1723.19%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView2: {
    position: "absolute",
    height: "78.57%",
    width: "17.39%",
    top: "180.95%",
    right: "-1668.12%",
    bottom: "-159.52%",
    left: "1750.72%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  barView3: {
    position: "absolute",
    height: "100%",
    width: "17.39%",
    top: "159.52%",
    right: "-1695.65%",
    bottom: "-159.52%",
    left: "1778.26%",
    borderRadius: 1,
    backgroundColor: "#333",
  },
  signalView: {
    position: "relative",
    backgroundColor: "#000",
    width: 17.25,
    height: 10.5,
  },
  statusBarService: {
    position: "absolute",
    height: "23.86%",
    width: "4.6%",
    top: "38.07%",
    right: "17.4%",
    bottom: "38.07%",
    left: "78%",
  },
  boundsView: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
  },
  locationIcon: {
    position: "absolute",
    height: "65.63%",
    width: "65.63%",
    top: "12.5%",
    right: "18.75%",
    bottom: "21.88%",
    left: "15.63%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  statusBarLocation: {
    position: "absolute",
    height: "80%",
    width: "28.07%",
    top: "10%",
    right: "0.88%",
    bottom: "10%",
    left: "71.05%",
  },
  text: {
    position: "absolute",
    transform: [
      {
        translateY: -10,
      },
    ],
    width: "61.4%",
    top: "50%",
    right: "32.46%",
    left: "6.14%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "SF Pro Display",
    color: "#000",
    textAlign: "center",
  },
  timeView: {
    position: "absolute",
    height: "45.45%",
    width: "15.2%",
    top: "27.27%",
    right: "80.8%",
    bottom: "27.27%",
    left: "4%",
    overflow: "hidden",
  },
  systemStatusBarLight: {
    position: "absolute",
    height: "5.42%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "94.58%",
    left: "0%",
  },
  savedText: {
    position: "absolute",
    height: "2.46%",
    width: "18.67%",
    top: "8%",
    right: "40.53%",
    bottom: "89.53%",
    left: "40.8%",
    fontSize: 24,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "600",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  appleLaunchesIOS16: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#3a3a3a",
    textAlign: "center",
  },
  iPadOS16Is: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#3a3a3a",
    textAlign: "left",
  },
  groupView: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView3: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView1: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView2: {
    position: "absolute",
    top: -1,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS161: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#3a3a3a",
    textAlign: "center",
  },
  iPadOS16Is1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease1: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate1: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp1: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#3a3a3a",
    textAlign: "left",
  },
  groupView3: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView4: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon1: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView4: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView5: {
    position: "absolute",
    top: 105,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS162: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#3a3a3a",
    textAlign: "center",
  },
  iPadOS16Is2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease2: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate2: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp2: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#3a3a3a",
    textAlign: "left",
  },
  groupView6: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 87,
  },
  rectangleView5: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon2: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView7: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView8: {
    position: "absolute",
    top: 211,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS163: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  iPadOS16Is3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease3: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate3: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp3: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  groupView9: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView6: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon3: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView10: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView11: {
    position: "absolute",
    top: 317,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS164: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  iPadOS16Is4: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease4: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate4: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp4: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  groupView12: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView7: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon4: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView13: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView14: {
    position: "absolute",
    top: 423,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS165: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  iPadOS16Is5: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease5: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate5: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp5: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  groupView15: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView8: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon5: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView16: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView17: {
    position: "absolute",
    top: 529,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS166: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  iPadOS16Is6: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease6: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate6: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp6: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  groupView18: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView9: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon6: {
    position: "absolute",
    top: 637.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView19: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView20: {
    position: "absolute",
    top: 635,
    left: 0,
    width: 323,
    height: 90,
  },
  appleLaunchesIOS167: {
    position: "absolute",
    top: 0,
    left: 0,
    fontSize: 18,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontWeight: "700",
    fontFamily: "Mulish",
    color: "#000",
    textAlign: "center",
  },
  iPadOS16Is7: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  upcomingMajorRelease7: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  theIPadOSOperate7: {
    margin: 0,
  },
  iPadOS16IsTheFourthAndUp7: {
    position: "absolute",
    top: 27,
    left: 0,
    fontSize: 14,
    letterSpacing: -0.24,
    lineHeight: 16,
    fontFamily: "Open Sans",
    color: "#000",
    textAlign: "left",
  },
  groupView21: {
    position: "absolute",
    top: 0,
    left: 128,
    width: 195,
    height: 75,
  },
  rectangleView10: {
    position: "absolute",
    top: 0,
    left: 0,
    borderRadius: 10,
    backgroundColor: "#d9d9d9",
    borderStyle: "solid",
    borderColor: "#b7b7b7",
    borderWidth: 3,
    width: 115,
    height: 90,
  },
  download1Icon7: {
    position: "absolute",
    top: 2.33,
    left: 1.67,
    borderRadius: 10,
    width: 111.67,
    height: 85.34,
  },
  groupView22: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 115,
    height: 90,
  },
  groupView23: {
    position: "absolute",
    top: 741,
    left: 0,
    width: 323,
    height: 90,
  },
  frameView: {
    position: "absolute",
    height: "78.2%",
    width: "86.13%",
    top: "19.7%",
    right: "6.93%",
    bottom: "2.09%",
    left: "6.93%",
  },
  icon: {
    width: 24,
    height: 24,
    flexShrink: 0,
  },
  vuesaxtwotonehome2Pressable: {
    position: "relative",
  },
  icon1: {
    width: 24,
    height: 24,
    flexShrink: 0,
    opacity: 0.5,
  },
  vuesaxtwotonesearchNormalPressable: {
    position: "relative",
  },
  vuesaxtwotonearchiveTickIcon: {
    position: "relative",
    width: 24,
    height: 24,
    flexShrink: 0,
    opacity: 0.5,
  },
  icon2: {
    width: 24,
    height: 24,
    flexShrink: 0,
    opacity: 0.5,
  },
  vuesaxtwotonesetting2Pressable: {
    position: "relative",
  },
  frameView1: {
    position: "absolute",
    top: 24,
    left: 33,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  frameView2: {
    position: "absolute",
    height: "8.74%",
    width: "100%",
    top: "91.26%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: "#fff",
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 30,
    elevation: 30,
    shadowOpacity: 1,
    overflow: "hidden",
  },
  rectangleView11: {
    position: "absolute",
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: 10,
    backgroundColor: "rgba(217, 217, 217, 0.3)",
  },
  searchSavedNews: {
    position: "absolute",
    height: "41.67%",
    width: "39.81%",
    top: "29.17%",
    right: "49.69%",
    bottom: "29.17%",
    left: "10.49%",
    fontSize: 15,
    letterSpacing: -0.24,
    lineHeight: 20,
    fontFamily: "DM Sans",
    color: "#3a3a3a",
    textAlign: "center",
  },
  vuesaxtwotonesearchNormalIcon: {
    position: "absolute",
    height: "34.03%",
    width: "5.04%",
    top: "32.99%",
    right: "92.54%",
    bottom: "32.98%",
    left: "2.42%",
    maxWidth: "100%",
    maxHeight: "100%",
    opacity: 0.5,
  },
  groupView24: {
    position: "absolute",
    height: "5.91%",
    width: "86.4%",
    top: "11.45%",
    right: "6.67%",
    bottom: "82.64%",
    left: "6.93%",
  },
  icbaselineKeyboardVoiceIcon: {
    position: "absolute",
    height: "2.22%",
    width: "4.8%",
    top: "13.3%",
    right: "12.53%",
    bottom: "84.48%",
    left: "82.67%",
    maxWidth: "100%",
    maxHeight: "100%",
  },
  savedView: {
    position: "relative",
    backgroundColor: "#fff",
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Saved1;
