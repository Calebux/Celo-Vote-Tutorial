const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import Splash1 from "./screens/Splash1";
import Settings from "./screens/Settings";
import Settings1 from "./screens/Settings1";
import Saved from "./screens/Saved";
import Search from "./screens/Search";
import ReadMode from "./screens/ReadMode";
import ReadMode1 from "./screens/ReadMode1";
import Home from "./screens/Home";
import Home1 from "./screens/Home1";
import ChooseNewsSource from "./screens/ChooseNewsSource";
import ChooseNewsSource1 from "./screens/ChooseNewsSource1";
import Location from "./screens/Location";
import Splash from "./screens/Splash";
import Settings2 from "./screens/Settings2";
import Settings3 from "./screens/Settings3";
import Saved1 from "./screens/Saved1";
import Search1 from "./screens/Search1";
import ReadMode2 from "./screens/ReadMode2";
import ReadMode3 from "./screens/ReadMode3";
import Home2 from "./screens/Home2";
import Home3 from "./screens/Home3";
import ChooseNewsSource2 from "./screens/ChooseNewsSource2";
import ChooseNewsSource3 from "./screens/ChooseNewsSource3";
import Location1 from "./screens/Location1";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(false);
  const SplashScreen = () => {
    return <Splash1 />;
  };
  React.useEffect(() => {
    setTimeout(() => {
      setHideSplashScreen(true);
    }, 1000);
  }, []);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Splash1"
              component={Splash1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings"
              component={Settings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings1"
              component={Settings1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Saved"
              component={Saved}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Search"
              component={Search}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ReadMode"
              component={ReadMode}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ReadMode1"
              component={ReadMode1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home"
              component={Home}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home1"
              component={Home1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChooseNewsSource"
              component={ChooseNewsSource}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChooseNewsSource1"
              component={ChooseNewsSource1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Location"
              component={Location}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Splash"
              component={Splash}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings2"
              component={Settings2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings3"
              component={Settings3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Saved1"
              component={Saved1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Search1"
              component={Search1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ReadMode2"
              component={ReadMode2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ReadMode3"
              component={ReadMode3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home2"
              component={Home2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home3"
              component={Home3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChooseNewsSource2"
              component={ChooseNewsSource2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChooseNewsSource3"
              component={ChooseNewsSource3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Location1"
              component={Location1}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : (
          <SplashScreen />
        )}
      </NavigationContainer>
    </>
  );
};
export default App;
